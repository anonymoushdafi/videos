import os
import imageio
import numpy as np
from typing import Union
import logging
import torch
import torchvision
from tqdm import tqdm
from einops import rearrange
import datetime
import pprint

def merge_weight(state_dict, pipeline, alpha):
    LORA_PREFIX_UNET = 'lora_unet'
    LORA_PREFIX_TEXT_ENCODER = 'lora_te'
    visited = []

    # directly update weight in diffusers model
    for key in state_dict:

        # it is suggested to print out the key, it usually will be something like below
        # "lora_te_text_model_encoder_layers_0_self_attn_k_proj.lora_down.weight"

        # as we have set the alpha beforehand, so just skip
        if '.alpha' in key or key in visited:
            continue

        if 'text' in key:
            layer_infos = key.split('.')[0].split(LORA_PREFIX_TEXT_ENCODER + '_')[-1].split('_')
            curr_layer = pipeline.text_encoder
        else:
            layer_infos = key.split('.')[0].split(LORA_PREFIX_UNET + '_')[-1].split('_')
            curr_layer = pipeline.unet

        # find the target layer
        temp_name = layer_infos.pop(0)
        while len(layer_infos) > -1:
            try:
                curr_layer = curr_layer.__getattr__(temp_name)
                if len(layer_infos) > 0:
                    temp_name = layer_infos.pop(0)
                elif len(layer_infos) == 0:
                    break
            except Exception:
                if len(temp_name) > 0:
                    temp_name += '_' + layer_infos.pop(0)
                else:
                    temp_name = layer_infos.pop(0)

        # org_forward(x) + lora_up(lora_down(x)) * multiplier
        pair_keys = []
        if 'lora_down' in key:
            pair_keys.append(key.replace('lora_down', 'lora_up'))
            pair_keys.append(key)
        else:
            pair_keys.append(key)
            pair_keys.append(key.replace('lora_up', 'lora_down'))

        # update weight
        if len(state_dict[pair_keys[0]].shape) == 4:
            weight_up = state_dict[pair_keys[0]].squeeze(3).squeeze(2).to(torch.float32)
            weight_down = state_dict[pair_keys[1]].squeeze(3).squeeze(2).to(torch.float32)
            curr_layer.weight.data += alpha * torch.mm(weight_up, weight_down).unsqueeze(2).unsqueeze(3)
        else:
            weight_up = state_dict[pair_keys[0]].to(torch.float32)
            weight_down = state_dict[pair_keys[1]].to(torch.float32)
            curr_layer.weight.data += alpha * torch.mm(weight_up, weight_down)

        # update visited list
        for item in pair_keys:
            visited.append(item)

def available_devices(threshold=5000,n_devices=None):
    """
    search for available GPU devices
    Args:
        threshold: the devices with larger memory than threshold is available
        n_devices: the number of devices
    Returns:
        device: the id for available GPU devices
    """
    memory = list(os.popen('nvidia-smi --query-gpu=memory.free --format=csv,nounits,noheader'))
    mem = [int(x.strip()) for x in memory]
    devices = []
    for i in range(len(mem)):
        if mem[i] > threshold:
            devices.append(i)
    device = devices if n_devices is None else devices[:n_devices]
    return device

def format_devices(devices):
    if isinstance(devices, list):
        return ','.join(map(str,devices))

def backup_profile(profile: dict, path):
    """
    backup args profile
    Args:
        profile: the args profile need to backup code
        path: the path for saving args profile
    """
    os.makedirs(path, exist_ok=True)
    path = os.path.join(path, "profile_{}.txt".format(datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")))
    s = pprint.pformat(profile)
    with open(path, 'w') as f:
        f.write(s)

def set_logger(path, file_path=None):
    os.makedirs(path,exist_ok=True)
    #logger to print information
    logger = logging.getLogger()
    logger.setLevel(level=logging.INFO)
    handler1 = logging.StreamHandler()
    if file_path is not None:
        handler2 = logging.FileHandler(os.path.join(path,file_path), mode='w')
    else:
        handler2 = logging.FileHandler(os.path.join(path, "logs.txt"), mode='w')
    formatter = logging.Formatter("%(asctime)s - %(message)s")
    handler1.setFormatter(formatter)
    handler2.setFormatter(formatter)
    logger.addHandler(handler1)
    logger.addHandler(handler2)

def save_tensor_images_folder(videos: torch.Tensor, path: str, rescale=False, n_rows=4):
    os.makedirs(path, exist_ok=True)
    videos = rearrange(videos, "b c t h w -> t b c h w")
    outputs = []
    for i, x in enumerate(videos):
        x = torchvision.utils.make_grid(x, nrow=n_rows)
        x = x.transpose(0, 1).transpose(1, 2).squeeze(-1)
        if rescale:
            x = (x + 1.0) / 2.0  # -1,1 -> 0,1
        x = (x * 255).numpy().astype(np.uint8)
        save_path = os.path.join(path, f"{i}.png")
        imageio.imsave(save_path, x)
        outputs.append(x)

def save_videos_grid(videos: torch.Tensor, path: str, rescale=False, n_rows=4, fps=8):
    videos = rearrange(videos, "b c t h w -> t b c h w")
    outputs = []
    for x in videos:
        x = torchvision.utils.make_grid(x, nrow=n_rows)
        x = x.transpose(0, 1).transpose(1, 2).squeeze(-1)
        if rescale:
            x = (x + 1.0) / 2.0  # -1,1 -> 0,1
        x = (x * 255).numpy().astype(np.uint8)
        outputs.append(x)

    os.makedirs(os.path.dirname(path), exist_ok=True)
    imageio.mimsave(path, outputs, fps=fps)

# DDIM Inversion
@torch.no_grad()
def init_prompt(prompt, pipeline):
    uncond_input = pipeline.tokenizer(
        [""], padding="max_length", max_length=pipeline.tokenizer.model_max_length,
        return_tensors="pt"
    )
    uncond_embeddings = pipeline.text_encoder(uncond_input.input_ids.to(pipeline.device))[0]
    text_input = pipeline.tokenizer(
        [prompt],
        padding="max_length",
        max_length=pipeline.tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
    text_embeddings = pipeline.text_encoder(text_input.input_ids.to(pipeline.device))[0]
    context = torch.cat([uncond_embeddings, text_embeddings])
    return context

def next_step(model_output: Union[torch.FloatTensor, np.ndarray], timestep: int,
              sample: Union[torch.FloatTensor, np.ndarray], ddim_scheduler):
    timestep, next_timestep = min(
        timestep - ddim_scheduler.config.num_train_timesteps // ddim_scheduler.num_inference_steps, 999), timestep
    alpha_prod_t = ddim_scheduler.alphas_cumprod[timestep] if timestep >= 0 else ddim_scheduler.final_alpha_cumprod
    alpha_prod_t_next = ddim_scheduler.alphas_cumprod[next_timestep]
    beta_prod_t = 1 - alpha_prod_t
    next_original_sample = (sample - beta_prod_t ** 0.5 * model_output) / alpha_prod_t ** 0.5
    next_sample_direction = (1 - alpha_prod_t_next) ** 0.5 * model_output
    next_sample = alpha_prod_t_next ** 0.5 * next_original_sample + next_sample_direction
    return next_sample

def get_multicontrol_pre_single(latents, t, context, unet, controlnets, controls, control_scale):
    for i, (image, scale, controlnet) in enumerate(zip(controls, control_scale, controlnets)):
        down_samples, mid_sample = controlnet(
            latents,
            t,
            encoder_hidden_states=context,
            controlnet_cond=image,
            return_dict=False,
        )
        down_samples = [
            down_samples * scale
            for down_samples in down_samples
        ]
        mid_sample *= scale

        # merge samples
        if i == 0:
            down_block_res_samples, mid_block_res_sample = down_samples, mid_sample
        else:
            down_block_res_samples = [
                samples_prev + samples_curr
                for samples_prev, samples_curr in zip(down_block_res_samples, down_samples)
            ]
            mid_block_res_sample += mid_sample

    noise_pred = unet(
        latents,
        t,
        encoder_hidden_states=context,
        down_block_additional_residuals=down_block_res_samples,
        mid_block_additional_residual=mid_block_res_sample,
    )["sample"]
    return noise_pred

def get_noise_pred_single(latents, t, context, unet, controlnet, controls, controlnet_conditioning_scale=1.0):
    down_block_res_samples, mid_block_res_sample = controlnet(
        latents,
        t,
        encoder_hidden_states=context,
        controlnet_cond=controls,
        return_dict=False,
    )
    down_block_res_samples = [
        down_block_res_sample * controlnet_conditioning_scale
        for down_block_res_sample in down_block_res_samples
    ]
    mid_block_res_sample *= controlnet_conditioning_scale
    noise_pred = unet(
        latents,
        t,
        encoder_hidden_states=context,
        down_block_additional_residuals=down_block_res_samples,
        mid_block_additional_residual=mid_block_res_sample,
    )["sample"]
    return noise_pred

def get_index(video_length, sub_frames, overlap):
    sub = 0
    starts = []
    ends = []
    while True:
        start = sub * (sub_frames - overlap)
        end = min(sub * (sub_frames - overlap) + sub_frames, video_length)
        sub += 1
        starts.append(start)
        ends.append(end)
        if end>=video_length:
            break
    return starts, ends

@torch.no_grad()
def ddim_loop(pipeline, ddim_scheduler, latent, num_inv_steps, prompt,controls, controlnet_conditioning_scale):
    context = init_prompt(prompt, pipeline)
    uncond_embeddings, cond_embeddings = context.chunk(2)
    all_latent = [latent]
    latent = latent.clone().detach()
    for i in tqdm(range(num_inv_steps)):
        t = ddim_scheduler.timesteps[len(ddim_scheduler.timesteps) - i - 1]
        noise_pred = get_noise_pred_single(latent, t, cond_embeddings, pipeline.unet, pipeline.controlnet, controls, controlnet_conditioning_scale)
        latent = next_step(noise_pred, t, latent, ddim_scheduler)
        all_latent.append(latent)
    return all_latent


@torch.no_grad()
def ddim_inversion(pipeline, ddim_scheduler, video_latent, num_inv_steps, prompt="", controls=None, controlnet_conditioning_scale=1.0):
    ddim_latents = ddim_loop(pipeline, ddim_scheduler, video_latent, num_inv_steps, prompt, controls, controlnet_conditioning_scale)
    return ddim_latents

def _gaussian_weights(length, var=0.01):
    """Generates a gaussian mask of weights for tile contributions"""
    from numpy import exp, pi, sqrt


    midpoint = (length - 1) / 2  # -1 because index goes from 0 to latent_width - 1
    x_probs = [
        exp(-(x - midpoint) * (x - midpoint) / (length * length) / (2 * var)) / sqrt(2 * pi * var)
        for x in range(length)
    ]

    return x_probs

@torch.no_grad()
def ddim_inversion_keyframe_long(pipeline, ddim_scheduler, video_latent, num_inv_steps, prompt="", controls=None, controlnet_conditioning_scale=1.0,video_length=100, sub_frames=24, overlap=8, var=0.01,key_weight=0.8):
    context = init_prompt(prompt, pipeline)
    uncond_embeddings, cond_embeddings = context.chunk(2)
    all_latent = [video_latent]
    latents = video_latent.clone().detach()
    starts, ends = get_index(video_length, sub_frames, overlap)
    keyframes = torch.tensor([starts])[0]
    weight = torch.tensor(_gaussian_weights(sub_frames, var), device=latents.device)
    weights = weight.reshape(1, 1, sub_frames, 1, 1)
    weights = weights.repeat(1, 4, 1, int(latents.shape[3]), int(latents.shape[4]))

    for i in tqdm(range(num_inv_steps)):
        t = ddim_scheduler.timesteps[len(ddim_scheduler.timesteps) - i - 1]
        noise_preds = []
        for start, end in zip(starts, ends):
            sub_latents = latents[:, :, start:end, :, :]
            sub_images = controls[:, :, start:end, :, :]
            noise_pred = get_noise_pred_single(sub_latents, t, cond_embeddings, pipeline.unet, pipeline.controlnet, sub_images,
                                               controlnet_conditioning_scale)
            noise_preds.append(noise_pred)

        whole_noise_pred = torch.zeros_like(latents).float()
        contributors = torch.zeros_like(latents).float()
        for start, end, noise_pred in zip(starts, ends, noise_preds):
            if end - start < sub_frames:
                weight = weights[:, :, :end - start, :, :]
            else:
                weight = weights
            whole_noise_pred[:, :, start:end, :, :] += (
                    noise_pred * weight
            )
            contributors[:, :, start:end, :, :] += weight
        whole_noise_pred /= contributors
        key_latents = latents[:, :, keyframes, :, :]
        key_images = controls[:, :, keyframes, :, :]
        noise_pred = get_noise_pred_single(key_latents, t, cond_embeddings, pipeline.unet, pipeline.controlnet,
                                           key_images, controlnet_conditioning_scale)
        whole_noise_pred[:, :, keyframes, :, :] = key_weight * noise_pred + (1 - key_weight) * whole_noise_pred[:, :, keyframes, :, :]
        latents = next_step(whole_noise_pred, t, latents, ddim_scheduler)
        all_latent.append(latents)
    return all_latent
