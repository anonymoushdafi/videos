## Environment
```
conda env create -f environment.yml
```
## Prepare Pretrained Text-to-Image Diffusion Model
Download the public [Stable Diffusion 1.5](https://huggingface.co/runwayml/stable-diffusion-v1-5/tree/main) and ControlNet 1.0 for [canny](https://huggingface.co/lllyasviel/sd-controlnet-canny/tree/main), [HED](https://huggingface.co/lllyasviel/sd-controlnet-hed), [depth](https://huggingface.co/lllyasviel/sd-controlnet-depth) and [pose](https://huggingface.co/lllyasviel/sd-controlnet-openpose). Put them in ```./``` .
## Text-driven Video Editing
```
python main.py --config_path configs/default/hed.yaml --video_path videos/car.mp4 --source 'a car' --target 'a red car' --out_root outputs/ --max_step 300 
```
The ```config_path``` is the path of config. The ```video_path``` is the path to the input video. The ```source``` is the source prompt for the source video. The ```target``` is the target prompt. The ```max_step``` is the step for training. The ```out_root``` is the path for saving results. 
## Image-driven Video Editing
```
python main_lora.py --config_path configs/default/lora.yaml --video_path videos/girl.mp4 --source 'a girl' --target 'evangelinelilly' --out_root outputs/lora --max_step 10 
```
The ```config_path``` is the path of config. The ```video_path``` is the path to the input video. The ```source``` is the source prompt for the source video. The ```target``` is the target prompt. The ```max_step``` is the step for training. The ```out_root``` is the path for saving results. \
The ```lora_path``` is the path for lora.
## Text-driven Video Editing for Long Video Editing
```
python main_long.py --config_path configs/default/long_hed.yaml --video_path videos/girl_face.mp4 --source 'a girl' --target 'a girl with exquisite and rich makeup' --out_root outputs/long --max_step 100 --video_length 100 --sub_frames 12 --key_weight 0.2 --overlap 10
```
The ```config_path``` is the path of config. The ```video_path``` is the path to the input video. The ```source``` is the source prompt for the source video. The ```target``` is the target prompt. The ```max_step``` is the step for training. The ```out_root``` is the path for saving results. \
The ```video_length``` is the length of total video. The ```sub_frames``` is the length of short video segments. The ```overlap``` is the length of overlap. The ```key_weight``` is the weight for key frame video.
